
import { Request, Response } from "express";
import { AppDataSource } from "../utils/db";
import { Order } from "../entities/orders.entity";
import { OrderDetail } from "../entities/order-detail.entity";
import { Menu } from "../entities/menu.entity";
import { User } from "../entities/user.entity";
import { Business } from "../entities/business.entity";

const orderRepo = AppDataSource.getRepository(Order);
const orderDetailRepo = AppDataSource.getRepository(OrderDetail);
const menuRepo = AppDataSource.getRepository(Menu);
const userRepo = AppDataSource.getRepository(User);
const businessRepo = AppDataSource.getRepository(Business);

export const getAllOrders = async (req: Request, res: Response) => {
    try {
        const orders = await orderRepo.find({
            relations: ["user", "business", "orderDetails", "orderDetails.menu", "delivery"]
        });
        res.json(orders);
    } catch (error) {
        res.status(500).json({ message: "Error al obtener órdenes", error });
    }
};

export const getOrderById = async (req: Request, res: Response) => {
    try {
        const order = await orderRepo.findOne({
            where: { order_id: parseInt(req.params.id) },
            relations: ["user", "business", "orderDetails", "orderDetails.menu", "delivery", "payments"]
        });

        if (!order) {
            return res.status(404).json({ message: "Orden no encontrada" });
        }

        res.json(order);
    } catch (error) {
        res.status(500).json({ message: "Error al obtener orden", error });
    }
};

export const createOrder = async (req: Request, res: Response) => {
    try {
        const { user_id, business_id, orderDetails, customer_name, customer_phone, delivery_address, order_notes } = req.body;

        // Validar que existan user y business
        const user = await userRepo.findOne({ where: { user_id } });
        if (!user) {
            return res.status(404).json({ message: "Usuario no encontrado" });
        }

        const business = await businessRepo.findOne({ where: { business_id } });
        if (!business) {
            return res.status(404).json({ message: "Negocio no encontrado" });
        }

        // Calcular total
        let total = 0;
        for (const detail of orderDetails) {
            const menu = await menuRepo.findOne({ where: { menu_id: detail.menu_id } });
            if (!menu) {
                return res.status(404).json({ message: `Producto con ID ${detail.menu_id} no encontrado` });
            }
            total += menu.price * detail.quantity;
        }

        // Crear la orden
        const newOrder = orderRepo.create({
            user,
            business,
            customer_name: customer_name || user.user_name,
            customer_phone: customer_phone || user.phone,
            delivery_address,
            order_notes,
            total,
            status: 'pending',
            delivery_status: 'unassigned',
            order_date: new Date()
        });

        const savedOrder = await orderRepo.save(newOrder);

        // Crear los detalles de la orden
        if (orderDetails && orderDetails.length > 0) {
            const details = [];
            
            for (const detail of orderDetails) {
                const menu = await menuRepo.findOne({ where: { menu_id: detail.menu_id } });
                if (!menu) continue;

                const orderDetail = orderDetailRepo.create({
                    order: savedOrder,
                    menu,
                    quantity: detail.quantity,
                    subtotal: menu.price * detail.quantity,
                    notes: detail.notes || ''
                });
                
                details.push(orderDetail);
            }
            
            await orderDetailRepo.save(details);
        }

        // Obtener la orden completa con relaciones
        const completeOrder = await orderRepo.findOne({
            where: { order_id: savedOrder.order_id },
            relations: ["user", "business", "orderDetails", "orderDetails.menu"]
        });

        res.status(201).json({ 
            message: "Orden creada exitosamente", 
            order: completeOrder 
        });
    } catch (error) {
        console.error("Error al crear orden:", error);
        res.status(500).json({ message: "Error al crear orden", error });
    }
};

export const updateOrderStatus = async (req: Request, res: Response) => {
    try {
        const { status, delivery_status } = req.body;
        const order = await orderRepo.findOne({
            where: { order_id: parseInt(req.params.id) }
        });

        if (!order) {
            return res.status(404).json({ message: "Orden no encontrada" });
        }

        if (status) order.status = status;
        if (delivery_status) order.delivery_status = delivery_status;

        const updatedOrder = await orderRepo.save(order);
        
        res.json({ 
            message: "Estado de orden actualizado", 
            order: updatedOrder 
        });
    } catch (error) {
        res.status(500).json({ message: "Error al actualizar estado", error });
    }
};

export const deleteOrder = async (req: Request, res: Response) => {
    try {
        const result = await orderRepo.delete(parseInt(req.params.id));

        if (result.affected === 0) {
            return res.status(404).json({ message: "Orden no encontrada" });
        }

        res.json({ message: "Orden eliminada" });
    } catch (error) {
        res.status(500).json({ message: "Error al eliminar orden", error });
    }
};