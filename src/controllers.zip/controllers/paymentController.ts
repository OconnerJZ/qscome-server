import { Request, Response } from "express";
import { AppDataSource } from "../utils/db";
import { Payment } from "../entities/payments.entity";

const paymentRepo = AppDataSource.getRepository(Payment);

export const createPayment = async (req: Request, res: Response) => {
    try {
        const { user_id, order_id, amount, payment_method } = req.body;

        const newPayment = paymentRepo.create({
            user: { user_id },
            order: { order_id },
            amount,
            payment_method,
            status: "pending"
        });

        await paymentRepo.save(newPayment);

        res.status(201).json({ message: "Pago registrado", payment: newPayment });
    } catch (error) {
        res.status(500).json({ message: "Error al procesar pago", error });
    }
};

export const updatePaymentStatus = async (req: Request, res: Response) => {
    try {
        const { status, gateway_id, gateway_response } = req.body;

        const payment = await paymentRepo.findOne({
            where: { payment_id: parseInt(req.params.id) }
        });

        if (!payment) {
            return res.status(404).json({ message: "Pago no encontrado" });
        }

        payment.status = status;
        if (gateway_id) payment.gateway_id = gateway_id;
        if (gateway_response) payment.gateway_response = JSON.stringify(gateway_response);

        await paymentRepo.save(payment);

        res.json({ message: "Estado de pago actualizado", payment });
    } catch (error) {
        res.status(500).json({ message: "Error al actualizar pago", error });
    }
};